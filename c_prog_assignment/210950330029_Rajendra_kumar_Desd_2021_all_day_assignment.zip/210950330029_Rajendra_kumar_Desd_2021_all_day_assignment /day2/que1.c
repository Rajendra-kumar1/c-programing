//*a C program to perform operations (+,*,-, / and %) on two whole numbers. 

#include<stdio.h>
int main()
{
int a; int b=a;
int v = 3*3;
char dt = '2';
 float d = (3.0/8+2-1);         // oprations(+,*,-,/)
 printf("%d\n", v);           // 9
 printf("%f\n", d);              // 1.375000
 return 0;
}                                  
                                


