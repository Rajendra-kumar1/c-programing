//*a program to find the area and the perimeter of a circle. 

#include <stdio.h>
int main()
{
int radius = 3;                 //* let radius replace 'r=3'
    float pi = 3.14;
 printf("The area of this circle is %f\n", pi * radius * radius);   
                                            //* circle = pi*r^2
    return 0;
}  
             //the area of this circle is 28.260000

