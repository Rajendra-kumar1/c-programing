//*a program to find out the sum of first n natural numbers.

#include<stdio.h>
int main()
{
    int n, i;

printf("Enter N number");

scanf("%d",&n);

printf( "Sum of N natural number \n");

i=n*(n+1)/2;
                                  // sum natural number
printf("%d" ,i);

    return 0;
}
