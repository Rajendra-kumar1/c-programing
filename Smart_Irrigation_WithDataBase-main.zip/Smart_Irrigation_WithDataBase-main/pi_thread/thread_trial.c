#include<pthread.h>
#include<stdio.h>
#include<stdlib.h>
#include<string.h>
#include<unistd.h>
#include<semaphore.h>
sem_t semWrite;
sem_t semRead;
int num ;
void* t1_func(void*arg)
{
    while(1)
    {
    sem_wait(&semWrite);   
    printf("Enter number in t1 Thread \n");
    scanf("%d",&num);
    printf("t1 is waiting ...\n");
    sem_post(&semRead);
    }
}

void* t2_func(void*arg)
{
    while(1)
    {
    sem_wait(&semRead);
    printf("Message from t2 thread!\n");
    printf("%d\n",num);
    sem_post(&semWrite);
    }
}

int main(int argv,const char*argc)
{
    pthread_t t1;
    pthread_t t2;
    sem_init(&semWrite,0,1);
    sem_init(&semRead,0,0);
    printf("Execution of main thread started!\n");
    pthread_create(&t1,NULL,t1_func,NULL);
    pthread_create(&t2,NULL,t2_func,NULL);
    pthread_join(t1,NULL);
    pthread_join(t2,NULL);
}