#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<linux/in.h>
#include<errno.h>
#include<pthread.h>
#include<stdlib.h>
#include<string.h>
#include<semaphore.h>

int sfd;
int cfd;
sem_t semWrite,semRead;
pthread_t Th1,Th2;
struct sockaddr_in saddr;
struct sockaddr_in caddr;

int len;
unsigned char buff[1024];
void* Th1_func(void* arg)
{  
    while(1)
    {
    sem_wait(&semRead);
    printf("Inside Th1 Thread!\n");
    bind(sfd,(struct sockaddr*)&saddr,sizeof(struct sockaddr_in));
    listen(sfd,5);
    len=sizeof(struct sockaddr_in);
    cfd=accept(sfd,(struct sockaddr*)&caddr,&len);
    read(cfd,buff,1024);
    //printf("client sent : %s\n",buff);
    sem_post(&semWrite);
    }
}
void* Th2_func(void* arg)
{
    while(1)
    {
    sem_wait(&semWrite);
    printf("Inside TH2 thread!\n");
    write(cfd,"Pi is available to serve you!\n",1024);
    printf("client sent : %s\n",buff);
    sem_post(&semRead);
    }
}
int main(int argc,char const* argv[])
{
    
    sfd=socket(AF_INET,SOCK_STREAM,0);
    saddr.sin_family=AF_INET;
    saddr.sin_addr.s_addr=inet_addr("192.168.0.101");
    saddr.sin_port=htons(2000);
    sem_init(&semWrite,0,0);
    sem_init(&semRead,0,1);
    pthread_create(&Th1,NULL,Th1_func,NULL);
    pthread_create(&Th2,NULL,Th2_func,NULL);
    pthread_join(Th1,NULL);
    pthread_join(Th2,NULL);
    close(sfd);
    close(cfd);
    return 0;
}