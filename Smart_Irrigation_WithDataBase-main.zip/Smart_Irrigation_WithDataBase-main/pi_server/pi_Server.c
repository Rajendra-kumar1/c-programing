#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<linux/in.h>
#include<errno.h>

int sfd;
int cfd;

struct sockaddr_in saddr;
struct sockaddr_in caddr;

int len;
unsigned char buff[1024];
int main(int argc,char const* argv[])
{
    sfd=socket(AF_INET,SOCK_STREAM,0);
    saddr.sin_family=AF_INET;
    saddr.sin_addr.s_addr=inet_addr("192.168.0.101");
    saddr.sin_port=htons(2000);
    while(1){
    bind(sfd,(struct sockaddr*)&saddr,sizeof(struct sockaddr_in));
    listen(sfd,5);
    len=sizeof(struct sockaddr_in);
    cfd=accept(sfd,(struct sockaddr*)&caddr,&len);
    if(write(cfd,"Pi is available to serve you!\n",1024) == -1)
    {
        perror("Error: ");
    }else
    {
        printf("Message is sent to client successfully!");
    }

    read(cfd,buff,1024);
    printf("client sent : %s\n",buff);
    }
    close(sfd);
    close(cfd);
    return 0;
}