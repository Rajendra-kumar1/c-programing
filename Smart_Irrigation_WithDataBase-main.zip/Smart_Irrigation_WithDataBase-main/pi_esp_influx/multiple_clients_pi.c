#include "HEADER.h" // Contains all the necessary header files.

#define PORT 8086  //default InfluxDB port number is 8086
#define IP   "192.168.0.103"  // ip of the host in this case i.e Raspberrypi.
#define DATABASE "MultifarmDATA" //database in influxDB
#define USERNAME "admin"       // auth. username for influxDB
#define PASSWORD "adminpassword" //auth. pass  for influxDB
#define HOSTNAME "pi-server"     // hostname for influx DB
#define SECONDS 15
#define LOOPS   100
#define BUFSIZE 8196

int sfd_esp; //file discriptor for esp32
int cfd_esp; // file discriptor for esp32
int loop,ret;
int sfd_DB; //file discriptor for influxDB
unsigned int i= 0;
//FARM structure for different farm fields
struct farmData 
{
    char temp[BUFSIZE];
    char soil_moisture[BUFSIZE];
    float soil_moisture_per;
    float t;
    char pump[1];
    char level[1];
}farm[2]; 

// variables to identify farms
int id;
char farmid[BUFSIZE];

char header[BUFSIZE];
char body[BUFSIZE];
char result[BUFSIZE];
int pexit(char * msg)
{
    perror(msg);
    exit(1);
}
sem_t semWrite,semRead,semId;
pthread_t ThRead,ThDB;
struct sockaddr_in saddr; //socket structure for esp32
struct sockaddr_in caddr; //socket structure for esp32
struct sockaddr_in srv_DB; //socket structure for influxDB

int len;
//unsigned char buff[1024]

//thread for reading data from respective farm
void* Th1_func(void* arg)
{  
    while(1)
    {   
    // locking the critical section to avoide corruption of data fields between multiple farms structure 
    sem_wait(&semRead);  // assigning semRead to be 0
    bind(sfd_esp,(struct sockaddr*)&saddr,sizeof(struct sockaddr_in));
    listen(sfd_esp,5);
    len=sizeof(struct sockaddr_in);
    cfd_esp=accept(sfd_esp,(struct sockaddr*)&caddr,&len);
    read(cfd_esp,farmid,1024);
    id= atoi(farmid);
    
    read(cfd_esp,farm[id].temp,1024);
    //farm[id].t= strtol(farm[id].temp);
    read(cfd_esp,farm[id].soil_moisture,1024);
     printf("Data Received from farm %d\n",id);
    printf("Weather Temperature at Farm : %s\n",farm[id].temp);
    printf("Soil moisture at Farm  : %s\n",farm[id].soil_moisture);
    //farm[id].soil_moisture_per= strtol(farm[id].soil_moisture);
    //int farm[id].soilper= atof(farm[id].soil_moisture);
    //farm[0].soil_moisture2_per= atoi(farm[0].soil_moisture2);
    farm[id].soil_moisture_per= atoi(farm[id].soil_moisture);
    farm[id].t= atoi(farm[id].temp);
   
    printf("Weather Temperature at Farm : %f\n",farm[id].t);
    printf("Soil moisture at Farm  : %f\n",farm[id].soil_moisture_per);
    sem_post(&semWrite);   // releasing the semWrite to be 1 
    }
}

void* TH_DB_func(void* arg)
{
    while(1)
    {
    sem_wait(&semWrite); // assigning semWrite to be 0 : LOCKING semaphore
    //Body1
    switch(id){
        case 0:     
               sprintf(body,"FARM0,pumpStatus=%s,waterLevel=%s Temperature=%f,sm=%f \n",HOSTNAME,USERNAME,farm[0].t,farm[id].soil_moisture_per);
               sprintf(header,"POST /write?db=%s&u=%s&p=%s HTTP/1.1\r\nHost: influx:8086\r\nContent-Length: %ld\r\n\r\n", 
                       DATABASE, USERNAME, PASSWORD, strlen(body));
               //printf("Send to InfluxDB the POST request bytes=%d \n->|%s|<-\n",strlen(header), header);
               printf("Send to InfluxDB the POST request bytes=%d \n",strlen(header));
               write(sfd_DB, header, strlen(header));
               if (ret < 0)
               pexit("Write Header request to InfluxDB failed");
               printf("Send to InfluxDB the data bytes=%d \n->|%s|<-\n",strlen(body), body);
               ret = write(sfd_DB, body, strlen(body));
               if (ret < 0)
               pexit("Write Data Body to InfluxDB failed");
               ret = read(sfd_DB, result, sizeof(result));
               if (ret < 0)
               pexit("Reading the result from InfluxDB failed");
               result[ret] = 0; /* terminate string */
               printf("Result returned from InfluxDB.is Success\n->|%s|<-\n",result);
               break;
        case 1:
               sprintf(body,"FARM1,PumpStatus=%s,WaterLevel=%s Temperature=%f,sm=%f \n",HOSTNAME,USERNAME,31.0670,farm[id].soil_moisture_per);
               sprintf(header,"POST /write?db=%s&u=%s&p=%s HTTP/1.1\r\nHost: influx:8086\r\nContent-Length: %ld\r\n\r\n", 
                DATABASE, USERNAME, PASSWORD, strlen(body));
               //printf("Send to InfluxDB the POST request bytes=%d \n->|%s|<-\n",strlen(header), header);
               printf("Send to InfluxDB the POST request bytes=%d \n",strlen(header));
               write(sfd_DB, header, strlen(header));
               if (ret < 0)
               pexit("Write Header request to InfluxDB failed");
               printf("Send to InfluxDB the data bytes=%d \n->|%s|<-\n",strlen(body), body);
               ret = write(sfd_DB, body, strlen(body));
               if (ret < 0)
               pexit("Write Data Body to InfluxDB failed");
               ret = read(sfd_DB, result, sizeof(result));
               if (ret < 0)
               pexit("Reading the result from InfluxDB failed");
               result[ret] = 0; /* terminate string */
               printf("Result returned from InfluxDB.is Success\n->|%s|<-\n",result);
               break;
               
    }

        sem_post(&semRead);
    }
}

int main(int argc,char const* argv[])
{
    //connection established with esp client//
    sfd_esp=socket(AF_INET,SOCK_STREAM,0);
    saddr.sin_family=AF_INET;
    saddr.sin_addr.s_addr=inet_addr("192.168.0.103");
    saddr.sin_port=htons(2000);

    //connection established with influxDB client//
    
    printf("Connecting socket to %s and port %d\n", IP, PORT);
    if((sfd_DB = socket(AF_INET, SOCK_STREAM,0)) <0) 
        pexit("socket() failed");

    srv_DB.sin_family = AF_INET;
    srv_DB.sin_addr.s_addr = inet_addr(IP);
    srv_DB.sin_port = htons(PORT);
    if(connect(sfd_DB, (struct sockaddr *)&srv_DB, sizeof(srv_DB)) <0) 
        pexit("connect() failed");

    sem_init(&semWrite,0,0);
    sem_init(&semRead,0,1);
   

    //Thread for reading farm data(temperature, humidity, Soil Moisture value, Pump and Valve Status)
    pthread_create(&ThRead,NULL,Th1_func,NULL);
    //Thread for sending each farm data to the DATABASE influxDB
    pthread_create(&ThDB,NULL,TH_DB_func,NULL);

    pthread_join(ThRead,NULL); 
    pthread_join(ThDB,NULL);
    close(sfd_esp);
}