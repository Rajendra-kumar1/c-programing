#include "HEADER.h" // Contains all the necessary header files.

#define PORT 8086  //default InfluxDB port number is 8086
#define IP   "192.168.0.100"  // ip of the host in this case i.e Raspberrypi.
#define DATABASE "Farm_DataCenter" //database in influxDB
#define USERNAME "admin"       // auth. username for influxDB
#define PASSWORD "adminpassword" //auth. pass  for influxDB
#define HOSTNAME "pi-server"     // hostname for influx DB
//#define FARMID   "farm1"
#define SECONDS 15
#define LOOPS   100
#define BUFSIZE 8196

int sfd_esp; //file discriptor for esp32
int cfd_esp; // file discriptor for esp32
int loop,ret;
int sfd_DB; //file discriptor for influxDB
unsigned int i= 0;
//FARM structure for different farm fields
struct farmData 
{
    int farmid;
    char temp[BUFSIZE];
    char soil_moisture1[BUFSIZE];
    char soil_moisture2[BUFSIZE];
    float soil_moisture1_per;
    float soil_moisture2_per;
}farm[2] ={{1},{2}}; 

char header[BUFSIZE];
char body[BUFSIZE];
char result[BUFSIZE];
int pexit(char * msg)
{
    perror(msg);
    exit(1);
}
sem_t semWrite,semRead,semId;
pthread_t ThRead,ThDB;
struct sockaddr_in saddr; //socket structure for esp32
struct sockaddr_in caddr; //socket structure for esp32
struct sockaddr_in srv_DB; //socket structure for influxDB

int len;
//unsigned char buff[1024]


void* Th1_func(void* arg)
{  
    while(1)
    {   
    // locking the critical section to avoide corruption of data fields between multiple farms structure 
    sem_wait(&semRead);  // assigning semRead to be 0
    printf("Receiving Data From Farm%d \n",i);
    bind(sfd_esp,(struct sockaddr*)&saddr,sizeof(struct sockaddr_in));
    listen(sfd_esp,5);
    len=sizeof(struct sockaddr_in);
    cfd_esp=accept(sfd_esp,(struct sockaddr*)&caddr,&len);
    read(cfd_esp,farm[0].temp,1024);
    printf("Weather Temperature at Farm%d : %s\n",i,farm[0].temp);

    read(cfd_esp,farm[0].soil_moisture1,1024);
    printf("Soil moisture 1 at Farm %d : %s\n",i,farm[0].soil_moisture1);
    
    read(cfd_esp,farm[0].soil_moisture2,1024);
    printf("Soil moisture 2 at Farm %d : %s\n",i,farm[0].soil_moisture2);

    farm[0].soil_moisture1_per= atoi(farm[0].soil_moisture1);
    farm[0].soil_moisture2_per= atoi(farm[0].soil_moisture2);

    sem_post(&semWrite);   // releasing the semWrite to be 1 
    }
}

void* TH_DB_func(void* arg)
{
    while(1)
    {
    sem_wait(&semWrite); // assigning semWrite to be 0 : LOCKING semaphore
    //Body1
    sprintf(body,"FieldData,host=%s,Temperature=%s sm1=%f,sm2=%f \n", HOSTNAME,farm[0].temp,farm[0].soil_moisture1_per,farm[0].soil_moisture2_per);
    sprintf(header,"POST /write?db=%s&u=%s&p=%s HTTP/1.1\r\nHost: influx:8086\r\nContent-Length: %ld\r\n\r\n", 
             DATABASE, USERNAME, PASSWORD, strlen(body));
    //printf("Send to InfluxDB the POST request bytes=%d \n->|%s|<-\n",strlen(header), header);
    printf("Send to InfluxDB the POST request bytes=%d \n",strlen(header));
        write(sfd_DB, header, strlen(header));
        if (ret < 0)
            pexit("Write Header request to InfluxDB failed");

        printf("Send to InfluxDB the data bytes=%d \n->|%s|<-\n",strlen(body), body);
        ret = write(sfd_DB, body, strlen(body));
        if (ret < 0)
            pexit("Write Data Body to InfluxDB failed");
        ret = read(sfd_DB, result, sizeof(result));
        if (ret < 0)
            pexit("Reading the result from InfluxDB failed");
        result[ret] = 0; /* terminate string */
        printf("Result returned from InfluxDB.is Success\n->|%s|<-\n",result);
        sem_post(&semRead);
    }
}

int main(int argc,char const* argv[])
{
    //connection established with esp client//
    sfd_esp=socket(AF_INET,SOCK_STREAM,0);
    saddr.sin_family=AF_INET;
    saddr.sin_addr.s_addr=inet_addr("192.168.0.100");
    saddr.sin_port=htons(2000);

    //connection established with influxDB client//
    
    printf("Connecting socket to %s and port %d\n", IP, PORT);
    if((sfd_DB = socket(AF_INET, SOCK_STREAM,0)) <0) 
        pexit("socket() failed");

    srv_DB.sin_family = AF_INET;
    srv_DB.sin_addr.s_addr = inet_addr(IP);
    srv_DB.sin_port = htons(PORT);
    if(connect(sfd_DB, (struct sockaddr *)&srv_DB, sizeof(srv_DB)) <0) 
        pexit("connect() failed");

    sem_init(&semWrite,0,0);
    sem_init(&semRead,0,1);
   

    //Thread for reading farm data(temperature, humidity, Soil Moisture value, Pump and Valve Status)
    pthread_create(&ThRead,NULL,Th1_func,NULL);
    //Thread for sending each farm data to the DATABASE influxDB
    pthread_create(&ThDB,NULL,TH_DB_func,NULL);

    pthread_join(ThRead,NULL);
    pthread_join(ThDB,NULL);
    close(sfd_esp);
}