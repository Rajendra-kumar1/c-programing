#include<stdio.h>
#include<sys/types.h>
#include<sys/socket.h>
#include<arpa/inet.h>
#include<unistd.h>
#include<linux/in.h>
#include<errno.h>
#include<pthread.h>
#include<stdlib.h>
#include<string.h>
#include<semaphore.h>
#include <netinet/in.h>