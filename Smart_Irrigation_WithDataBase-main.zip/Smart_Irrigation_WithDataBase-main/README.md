##Smart Irrigation with DataBase
# Hardware - Solenoid Valve x 2 , 12v Pump, pipe 5mm length 5 m, 4 channel Relay, LCD(16x2)
# Sensors - Soil Moisture Sensors x2 , DHT11 Sensors .
# Boards Details - ESP32,ESP8266, Raspberry pi
# Program Flow-
![image](https://user-images.githubusercontent.com/64128707/162784757-0c1af196-f43f-4d0e-98a2-32d7bd634697.png)
